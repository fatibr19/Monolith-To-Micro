package com.example.projetSI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetSiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetSiApplication.class, args);
	}

}
