package com.example.projetSI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetSiApplicationTests {

	@Test
	void contextLoads() {
	}

}
